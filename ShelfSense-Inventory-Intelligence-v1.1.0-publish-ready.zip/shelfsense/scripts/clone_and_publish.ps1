[CmdletBinding()]
param(
    [string]$RepositoryPath = (Join-Path $HOME "source\retail-sales-sql-python-analysis")
)

$ErrorActionPreference = "Stop"
$Remote = "https://github.com/Timesyou/retail-sales-sql-python-analysis.git"
$Publisher = Join-Path $PSScriptRoot "publish_to_github.ps1"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git for Windows was not found. Install Git for Windows and retry."
}

if (-not (Test-Path -LiteralPath $RepositoryPath)) {
    $Parent = Split-Path -Parent $RepositoryPath
    if ($Parent -and -not (Test-Path -LiteralPath $Parent)) {
        New-Item -ItemType Directory -Path $Parent -Force | Out-Null
    }
    Write-Host "Cloning $Remote into $RepositoryPath" -ForegroundColor Cyan
    & git clone $Remote $RepositoryPath
    if ($LASTEXITCODE -ne 0) {
        throw "Clone failed. Check your internet connection and GitHub sign-in."
    }
}
else {
    & git -C $RepositoryPath rev-parse --is-inside-work-tree *> $null
    if ($LASTEXITCODE -ne 0) {
        throw "The destination exists but is not a Git repository: $RepositoryPath"
    }
    $ActualRemote = (& git -C $RepositoryPath remote get-url origin).Trim()
    if ($LASTEXITCODE -ne 0 -or $ActualRemote -notin @($Remote, $Remote.TrimEnd('.git'))) {
        throw "Safety check failed. The existing folder does not point to $Remote"
    }
}

& $Publisher -RepositoryPath $RepositoryPath
