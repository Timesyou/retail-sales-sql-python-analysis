[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$RepositoryPath
)

$ErrorActionPreference = "Stop"
$RemoteUrl = "https://github.com/Timesyou/retail-sales-sql-python-analysis.git"
$ExpectedRemotes = @(
    $RemoteUrl,
    "https://github.com/Timesyou/retail-sales-sql-python-analysis",
    "git@github.com:Timesyou/retail-sales-sql-python-analysis.git",
    "git@github.com:Timesyou/retail-sales-sql-python-analysis"
)
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git for Windows was not found. Install Git for Windows and retry."
}
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python 3.10 or later was not found on PATH. Install Python and retry."
}
& python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)"
if ($LASTEXITCODE -ne 0) { throw "Python 3.10 or later is required. No repository changes were made." }
if (-not (Test-Path -LiteralPath $RepositoryPath -PathType Container)) {
    throw "Repository folder does not exist: $RepositoryPath"
}
$RepositoryPath = (Resolve-Path -LiteralPath $RepositoryPath).Path

& git -C $RepositoryPath rev-parse --is-inside-work-tree *> $null
if ($LASTEXITCODE -ne 0) {
    throw "The target folder is not a Git repository: $RepositoryPath"
}
$Remote = (& git -C $RepositoryPath remote get-url origin).Trim()
if ($LASTEXITCODE -ne 0 -or $Remote -notin $ExpectedRemotes) {
    throw "Safety check failed. origin must point to Timesyou/retail-sales-sql-python-analysis. Found: $Remote"
}
$Status = & git -C $RepositoryPath status --porcelain
if ($LASTEXITCODE -ne 0) {
    throw "Could not inspect the repository working tree."
}
if ($Status) {
    throw "The target clone has uncommitted changes. Nothing was overwritten. Commit or stash them, then retry."
}

Write-Host "Checking out the latest main branch..." -ForegroundColor Cyan
& git -C $RepositoryPath fetch origin main
if ($LASTEXITCODE -ne 0) { throw "Could not fetch origin/main. No project files were copied." }
& git -C $RepositoryPath switch main
if ($LASTEXITCODE -ne 0) { throw "Could not switch to main. No project files were copied." }
& git -C $RepositoryPath pull --ff-only origin main
if ($LASTEXITCODE -ne 0) { throw "Could not fast-forward main. No project files were copied." }

$BaseBranch = "feature/shelfsense-inventory-intelligence-v1.1.0"
$ExistingBranch = & git -C $RepositoryPath ls-remote --heads origin $BaseBranch
if ($LASTEXITCODE -ne 0) { throw "Could not check whether the feature branch already exists." }
$ExistingLocalBranch = & git -C $RepositoryPath branch --list $BaseBranch
if ($LASTEXITCODE -ne 0) { throw "Could not inspect local branch names." }
if ($ExistingBranch -or $ExistingLocalBranch) {
    $Branch = "$BaseBranch-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
} else {
    $Branch = $BaseBranch
}
& git -C $RepositoryPath switch --create $Branch
if ($LASTEXITCODE -ne 0) { throw "Could not create feature branch $Branch." }

Write-Host "Running the project checks before staging..." -ForegroundColor Cyan
$PreviousPythonPath = $env:PYTHONPATH
try {
    $env:PYTHONPATH = Join-Path $ProjectRoot "src"
    Push-Location $ProjectRoot
    try {
        & python -m unittest discover -s tests -v
        if ($LASTEXITCODE -ne 0) { throw "Unit tests failed. No files were staged or pushed." }
        & python -m compileall -q src tests
        if ($LASTEXITCODE -ne 0) { throw "Python compilation failed. No files were staged or pushed." }
        $DemoOutput = Join-Path $env:TEMP "shelfsense-publish-check"
        if (Test-Path -LiteralPath $DemoOutput) { Remove-Item -LiteralPath $DemoOutput -Recurse -Force }
        & python -m shelfsense --sales data/sales.csv --inventory data/inventory.csv --output $DemoOutput
        if ($LASTEXITCODE -ne 0) { throw "The demonstration run failed. No files were staged or pushed." }
        $VerifyCode = @'
import json
import sqlite3
from pathlib import Path
import os
out = Path(os.environ["TEMP"]) / "shelfsense-publish-check"
required = ("dashboard.html", "sku_performance.csv", "replenishment_plan.csv", "summary.json", "shelfsense.sqlite")
missing = [name for name in required if not (out / name).is_file()]
if missing:
    raise SystemExit(f"Missing demo outputs: {missing}")
with sqlite3.connect(out / "shelfsense.sqlite") as db:
    integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok":
        raise SystemExit(f"SQLite integrity check failed: {integrity}")
summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
if summary.get("sku_count") != 9 or summary.get("transaction_lines") != 652:
    raise SystemExit(f"Unexpected sample summary: {summary}")
print("Demo outputs and SQLite integrity verified.")
'@
        $VerifyCode | python -
        if ($LASTEXITCODE -ne 0) { throw "Demo output verification failed. No files were staged or pushed." }
    }
    finally {
        Pop-Location
    }
}
finally {
    $env:PYTHONPATH = $PreviousPythonPath
}

Write-Host "Copying the project into the clean feature branch..." -ForegroundColor Cyan
$ExcludedNames = @(".git", ".venv", "venv", "__pycache__", ".pytest_cache", "build", "dist", "htmlcov")
Get-ChildItem -LiteralPath $ProjectRoot -Force | ForEach-Object {
    if ($_.Name -in $ExcludedNames -or $_.Name.EndsWith(".egg-info")) { return }
    if ($_.PSIsContainer) {
        $TargetDirectory = Join-Path $RepositoryPath $_.Name
        if (-not (Test-Path -LiteralPath $TargetDirectory)) {
            New-Item -ItemType Directory -Path $TargetDirectory -Force | Out-Null
        }
        Get-ChildItem -LiteralPath $_.FullName -Force | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $TargetDirectory -Recurse -Force
        }
    }
    else {
        Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $RepositoryPath $_.Name) -Force
    }
}

# Remove the uploaded transport archive and the temporary, one-off workflow.
$ArchivePath = Join-Path $RepositoryPath "ShelfSense-Inventory-Intelligence-v1.1.0.zip"
if (Test-Path -LiteralPath $ArchivePath) { Remove-Item -LiteralPath $ArchivePath -Force }
$TemporaryWorkflow = Join-Path $RepositoryPath ".github\workflows\publish-archive.yml"
if (Test-Path -LiteralPath $TemporaryWorkflow) { Remove-Item -LiteralPath $TemporaryWorkflow -Force }

# Keep generated local database files out of version control.
$DemoDatabase = Join-Path $RepositoryPath "demo-output\shelfsense.sqlite"
if (Test-Path -LiteralPath $DemoDatabase) { Remove-Item -LiteralPath $DemoDatabase -Force }
$IgnoreFile = Join-Path $RepositoryPath ".gitignore"
if (Test-Path -LiteralPath $IgnoreFile) {
    $Lines = Get-Content -LiteralPath $IgnoreFile
    $Lines = $Lines | Where-Object { $_.Trim() -ne "!demo-output/shelfsense.sqlite" }
    Set-Content -LiteralPath $IgnoreFile -Value $Lines -Encoding UTF8
}

# Remove bytecode created by the compile check before the project is staged.
Get-ChildItem -LiteralPath $RepositoryPath -Recurse -Directory -Force | Where-Object { $_.Name -eq "__pycache__" } | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Recurse -Force
}
Get-ChildItem -LiteralPath $RepositoryPath -Recurse -File -Force | Where-Object { $_.Extension.ToLowerInvariant() -eq ".pyc" } | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Force
}

# Exclude local virtual environments, caches, databases and secret files.
$BadFiles = Get-ChildItem -LiteralPath $RepositoryPath -Recurse -Force -File | Where-Object {
    $_.FullName -notmatch '[\\/]\.git[\\/]' -and (
        $_.Name -eq ".env" -or $_.Name.StartsWith(".env.") -or
        $_.Extension.ToLowerInvariant() -in @(".pem", ".key", ".sqlite", ".db", ".pyc")
    )
}
if ($BadFiles) {
    $BadFiles | ForEach-Object { Write-Host "Rejected file: $($_.FullName)" -ForegroundColor Red }
    throw "A secret or generated file was found. Nothing was committed or pushed."
}

& git -C $RepositoryPath add --all
if ($LASTEXITCODE -ne 0) { throw "git add failed. No push was attempted." }
$StagedNames = & git -C $RepositoryPath diff --cached --name-only
if ($LASTEXITCODE -ne 0) { throw "Could not inspect staged files. No push was attempted." }
if (-not $StagedNames) { throw "No changes were staged. No push was attempted." }
Write-Host "Files prepared for the pull request:" -ForegroundColor Cyan
$StagedNames | ForEach-Object { Write-Host "  $_" }

& git -C $RepositoryPath diff --cached --check
if ($LASTEXITCODE -ne 0) { throw "Whitespace validation failed. No commit or push was attempted." }
& git -C $RepositoryPath commit -m "Add ShelfSense retail inventory intelligence project"
if ($LASTEXITCODE -ne 0) { throw "git commit failed. No push was attempted." }
& git -C $RepositoryPath push --set-upstream origin $Branch
if ($LASTEXITCODE -ne 0) { throw "Push failed. The local feature branch is preserved. Review the Git error and retry the push." }

$EncodedBranch = [Uri]::EscapeDataString($Branch)
$CompareUrl = "https://github.com/Timesyou/retail-sales-sql-python-analysis/compare/main...$EncodedBranch?expand=1"
Write-Host "Feature branch pushed successfully: $Branch" -ForegroundColor Green
Write-Host "Pull request link: $CompareUrl" -ForegroundColor Green

if (Get-Command gh -ErrorAction SilentlyContinue) {
    & gh auth status --hostname github.com *> $null
    if ($LASTEXITCODE -eq 0) {
        & gh pr create --repo "Timesyou/retail-sales-sql-python-analysis" --base main --head $Branch --title "Add ShelfSense inventory intelligence project" --body "Adds the ShelfSense retail analytics and inventory replenishment application, synthetic sample data, SQL schema and examples, a local HTML dashboard, methodology documentation, and automated tests. The branch publisher runs the unit tests, compiles source, executes the sample analysis, verifies generated SQLite integrity, excludes the uploaded ZIP and temporary workflow, and scans for secret or generated files. Demonstration figures are synthetic."
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Pull request created successfully." -ForegroundColor Green
            return
        }
        Write-Warning "The branch was pushed, but GitHub CLI could not create the pull request. Open the compare link shown above."
    }
}

try { Start-Process $CompareUrl } catch { Write-Warning "Open this link to create the pull request: $CompareUrl" }
Write-Host "The branch is pushed. If a pull request was not created automatically, select 'Create pull request' on the opened GitHub page." -ForegroundColor Yellow
