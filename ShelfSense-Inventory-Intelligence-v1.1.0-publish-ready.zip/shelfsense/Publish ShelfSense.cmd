@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\clone_and_publish.ps1"
if errorlevel 1 (
    echo.
    echo Publishing did not complete. Review the error above.
    pause
    exit /b 1
)
echo.
echo Publishing steps finished. Review the GitHub page opened by the script.
pause
